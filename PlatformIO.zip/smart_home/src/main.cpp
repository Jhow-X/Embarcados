#include <Arduino.h>

/**
 * Created by K. Suwatchai (Mobizt)
 *
 * Email: k_suwatchai@hotmail.com
 *
 * Github: https://github.com/mobizt/Firebase-ESP8266
 *
 * Copyright (c) 2022 mobizt
 *
 */

/** This example will show how to authenticate using
 * the legacy token or database secret with the new APIs (using config and auth data).
 */

#if defined(ESP32)
#include <WiFi.h>
#include <FirebaseESP32.h>
#elif defined(ESP8266)
#include <ESP8266WiFi.h>
#include <FirebaseESP8266.h>
#include <ctype.h>
#include <string.h>
#include <IRremoteESP8266.h>
#include <IRrecv.h>
#include <IRutils.h>
#endif

//Biblioteca para funcionamento do sensor de temperatura e umidade DHT11
#include <SoftwareSerial.h>

// Provide the RTDB payload printing info and other helper functions.
#include <addons/RTDBHelper.h>

/* 1. Define the WiFi credentials */
#define WIFI_SSID "LIVE TIM_4225_2G"
#define WIFI_PASSWORD "hxXpz3gY"

// Define databank credentials
#define DATABASE_URL "https://edmr-jcsc-embarcadoav2-default-rtdb.firebaseio.com/"
#define DATABASE_SECRET "d26ZpaZPJFlmXc8g7ssVOKAinUK5Sl51iq569eDw"

#define Pin_ST_NUCLEO_RX    5  //Pino D1 da placa Node MCU
#define Pin_ST_NUCLEO_TX    4  //Pino D2 da placa Node MCU
SoftwareSerial SSerial(Pin_ST_NUCLEO_RX, Pin_ST_NUCLEO_TX);

// Variaveis do IR

unsigned long  MyData;
IRrecv irrecv(14);
decode_results results;

/* 3. Define the Firebase Data object */
FirebaseData fbdo;

/* 4, Define the FirebaseAuth data for authentication data */
FirebaseAuth auth;

/* Define the FirebaseConfig data for config data */
FirebaseConfig config;

// Headers


// Variaveis globais

char c;
char buff[100];
int i = 0; int k = 0;
char delim[] = "$";
char *infos[2];
int prevstate=0;
int data =0;


void setup()
{
    Serial.begin(115200);
    SSerial.begin(115200);
 

    WiFi.begin(WIFI_SSID, WIFI_PASSWORD);
    Serial.print("Connecting to Wi-Fi");
    while (WiFi.status() != WL_CONNECTED)
    {
        Serial.print(".");
        delay(300);
    }
    Serial.println();
    Serial.print("Connected with IP: ");
    Serial.println(WiFi.localIP());
    Serial.println();
    irrecv.enableIRIn();  // Start the receiver
    Serial.print("IRrecv is now running and waiting for IR message on Pin ");
    Serial.println();

    Serial.printf("Firebase Client v%s\n\n", FIREBASE_CLIENT_VERSION);

    /* Assign the certificate file (optional) */
    // config.cert.file = "/cert.cer";
    // config.cert.file_storage = StorageType::FLASH;

    /* Assign the database URL and database secret(required) */
    config.database_url = DATABASE_URL;
    config.signer.tokens.legacy_token = DATABASE_SECRET;

    Firebase.reconnectWiFi(true);

    /* Initialize the library with the Firebase authen and config */
    Firebase.begin(&config, &auth);

    // Or use legacy authenticate method
    // Firebase.begin(DATABASE_URL, DATABASE_SECRET);
}

void loop() {
  // Informacoes vindas da nucleo
  if((SSerial.available())){
    while((c = SSerial.read()) !='#'){
      if(isascii(c)){
        // Serial.write(c);
        buff[i] = c;
        i++;
      }
    }
    buff[i] = '\0';
    char *ptr = strtok(buff,delim);
    while (ptr != NULL){
      infos[k]=ptr;
      ptr = strtok(NULL,delim);
      k++;
    }
    Firebase.setString(fbdo,"/Home/Temperatura",infos[0]);
    Firebase.setString(fbdo,"/Home/Luminosidade",infos[1]);
    
    // for(int j =0; j<i; j++){
    //   Serial.write(buff[j]);
    // }
    i=0;
    k=0;
    delay(10);
  }


  Firebase.getInt(fbdo,"/Control/Control");
  prevstate = data;
  data = fbdo.intData();
  // int data = 1;

  if((data> 0) && (prevstate != data)){
    SSerial.write('a');
  }
  if((data == 0) && (prevstate != data)){
    SSerial.write('b');
  }
  // SSerial.write(Serial.read());
  delay(10);
}


    // Firebase.setInt(fbdo,"/Home/Temperatura",ct);
    // Firebase.getInt(fbdo,"/Home/Temperatura");
    // Firebase.setInt(fbdo,"/Home/Luminosidade",ct);
    // Firebase.setInt(fbdo,"/Home/Presentes",ct);
